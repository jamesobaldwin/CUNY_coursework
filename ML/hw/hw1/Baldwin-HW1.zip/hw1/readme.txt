# CSC 474020 Machine Learning
# HW1: James Baldwin
# Submitted: September 21, 2024

1.What problems did you finish? 

I completed all of the problems.

2.What platform did you use?

I used both Mac and Linux (Ubuntu 20.04) when working on this homework.

3.Resources that helped me 

Geeksforgeeks and numpy documentation helped with recalling the behavior of specific functions. ChatGPT was useful in tracking the dimensionality of some of the vectorized computations. 
